from typing import OrderedDict
import backtrader as bt
from datetime import datetime
from backtrader import comminfo
import pandas as pd
from collections import deque
import quantstats

"""
加入佣金，保证金，仓位，每笔净收益，初始资金回测
"""
class CustomData(bt.feeds.PandasData):
    lines = ('predicted',)
    params = (
        ("predicted",-1),
    )

class CommInfo(bt.CommInfoBase):
    params = (
        ('stocklike',False),
        ('commtype',bt.CommInfoBase.COMM_PERC),  # 使用百分比佣金
    )

    def _getcommission(self, size, price, pseudoexec):
        return abs(size) * price * self.p.commission * self.p.mult
    
    def get_margin(self, price):
        return price * self.p.mult * self.p.margin

class TestStrategy(bt.Strategy):
    params = (
        ('exitbars', 4),
    )

    def log(self, txt, dt=None):
        ''' Logging function fot this strategy'''
        dt = dt or self.datas[0].datetime.datetime(0)
        print('%s, %s' % (dt.isoformat(), txt))

    def __init__(self):
        # Keep a reference to the "close" line in the data[0] dataseries
        self.dataclose = self.datas[0].close
        self.datatime = self.datas[0].datetime
        self.data_predicted = self.datas[0].predicted
        self.order_short_queue = deque(maxlen=5)
        # data = pd.read_csv("s_data.csv")
        # data = data.loc[ : , ~data.columns.str.contains("^Unnamed")]
        # data.time = pd.to_datetime(data.time, format='%Y-%m-%d %H:%M:%S')
        # data.columns = ['datetime','open','high','low','close','volume','predicted']
        # data.set_index('datetime',inplace=True,drop=True)
        # self.predicted = data.predicted.to_dict()
        # To keep track of pending orders and buy price/commission
        self.short_order = None
        self.buyprice = None
        self.buycomm = None

    def notify_order(self, order):
        if order.status in [order.Submitted, order.Accepted]:
            # Buy/Sell order submitted/accepted to/by broker - Nothing to do
            return

        # Check if an order has been completed
        # Attention: broker could reject order if not enough cash
        if order.status in [order.Completed]:
            if order.issell():
                self.log(
                    'Short EXECUTED, Price: %.2f, Cost: %.2f, Comm %.2f' %
                    (order.executed.price,
                     order.executed.value,
                     order.executed.comm))

                # self.buyprice = order.executed.price
                # self.buycomm = order.executed.comm
                # print(order.executed.dt,)
                order_dic = dict()
                order_dic["id"] = order.ref
                order_dic["open_time"] = self.datas[0].datetime.datetime(0)
                order_dic["open_type"] = "short_open"
                order_dic["open_price"] = order.executed.price
                order_dic["bar_executed"] = len(self)
                order_dic["close_time"] = None
                order_dic["close_type"] = "short_close"
                # print(order_dic)
                self.order_short_queue.append(order_dic)
                

            else:  # close
                
                # print(len(self),self.order_queue[0]['bar_executed'])
                if self.order_short_queue and len(self) == (self.order_short_queue[0]['bar_executed'] + self.params.exitbars+1):
                    self.log('CLOSE EXECUTED, Price: %.2f, Cost: %.2f, Comm %.2f, pnl1 %.2f, pnl2 %.2f' %
                         (order.executed.price,
                          order.executed.value,
                          order.executed.comm,
                          order.executed.pnl,
                          (order.executed.price-self.order_short_queue[0]['open_price']-order.executed.comm * 2)
                          ))
                    self.order_short_queue.popleft()

            self.bar_executed = len(self)

        elif order.status in [order.Canceled, order.Margin, order.Rejected]:
            self.log('Order Canceled/Margin/Rejected')

        self.short_order = None

    def notify_trade(self, trade):
        if not trade.isclosed:
            return

        self.log('OPERATION PROFIT, GROSS %.2f, NET %.2f' %
                 (trade.pnl, trade.pnlcomm))

    def next(self):
        
        # Simply log the closing price of the series from the reference
        self.log('Close, %.2f,  Predicted, %.2f' % (self.dataclose[0],self.data_predicted[0]))
        if self.order_short_queue:
            print('bar现时长度:',len(self),'出队运行bar记录:',self.order_short_queue[0]['bar_executed'])
        # Check if an order is pending ... if yes, we cannot send a 2nd one
        if self.short_order:
            return  
        # print("oposition",self.position)
        # print("opositions",self.getpositions())
        # Check if we are in the market
        for i in self.order_short_queue:
            print(i)
        print("positions:",self.getposition().size)
        # Not yet ... we MIGHT BUY if ...
        if self.data_predicted[0]==-1:
            self.log('Short CREATE, %.2f' % self.dataclose[0])

            # Keep track of the created order to avoid a 2nd order
            self.short_order = self.sell()
            # print("order",self.order)
        if self.order_short_queue and len(self) >= (self.order_short_queue[0]['bar_executed'] + self.params.exitbars):
            self.log('Close CREATE, %.2f' % self.dataclose[0])
                # Keep track of the created order to avoid a 2nd order
            self.short_order = self.close(size = 1)
        



if __name__ == '__main__':
    # Create a cerebro entity
    cerebro = bt.Cerebro()

    # Add a strategy
    cerebro.addstrategy(TestStrategy)
    print('策略加载完毕')
    data = pd.read_csv('s_data.csv')
    data = data.loc[ : , ~data.columns.str.contains("^Unnamed")]
    data.time = pd.to_datetime(data.time, format='%Y-%m-%d %H:%M:%S')
    data.columns = ['datetime','open','high','low','close','volume','predicted']
    data.set_index('datetime',inplace=True,drop=True)
    data['openinterest'] = 0
    data = CustomData(dataname=data,
                        fromdate = datetime(2021,1,11,18,17,0),
                        todate = datetime(2021,8,16,0,0,0)  #2021,8,16,0,0,0
                        )
    # Add the Data Feed to Cerebro
    cerebro.adddata(data)
    print('数据加载完毕')
    
    # Set our desired cash start
    cerebro.broker.setcash(1000000.0)
    comminfo = CommInfo(
        commission=0.018,
        mult = 1,
        margin = 0.02,
        leverage=100/2
    )
    cerebro.broker.addcommissioninfo(comminfo)
    # Print out the starting conditions
    print('Starting Portfolio Value: %.2f' % cerebro.broker.getvalue())

    cerebro.addanalyzer(bt.analyzers.PyFolio, _name='PyFolio')
    # Run over everything
    back = cerebro.run()  # 运行一个策略就返回一个对象
    # Print out the final result
    print('Final Portfolio Value: %.2f' % cerebro.broker.getvalue())

    # # Plot the result
    # cerebro.plot()


    strat = back[0]
    portfolio_stats = strat.analyzers.getbyname('PyFolio')
    returns, positions, transactions, gross_lev = portfolio_stats.get_pf_items()
    returns.index = returns.index.tz_convert(None)
    import pandas as pd

    quantstats.reports.html(returns, output='stats.html', title='BTC Sentiment')
