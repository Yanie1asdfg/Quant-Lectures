import pandas as pd
import talib
import numpy as np
from datetime import datetime
import math 


def ud_ma(data,ma):
    '''
    上穿下穿函数
    此根K线open小于等于均值，close大于等于均值，标记为1
    此根K线open大于等于均值，close小于等于均值，标记为-1
    其余为0
    '''
    data['ma'] = data['close'].rolling(ma).mean()
    label = "ud_ma"+str(ma)
    data.loc[(data.open<=data.ma)&(data.close>=data.ma),label]=1
    data.loc[(data.open>=data.ma)&(data.close<=data.ma),label]=-1
    data.loc[(data[label]!=1)&(data[label]!=-1)&(data.ma.isnull()==False),label]=0
    data = data.drop(['ma'],axis=1)
    return data

def macd_axis(data):
    '''
    macd 轴上为1，轴下为-1
    '''
    macd_tmp = talib.MACDEXT(data.close, fastperiod=12, fastmatype=1, slowperiod=26, slowmatype=1, signalperiod=9, signalmatype=1)     
    MACD = macd_tmp[2]*2
    data['MACD'] = np.sign(MACD)
    return data

def MOM(data,n):
    """
    几日收益率
    """
    data['MoM'+str(n)] = (data['close']-data['close'].shift(n))/data['close'].shift(n)
    return data

def weekofday(data,column):
    """
    :param column:字符串时间列名
    """
    data['datetime'] = pd.to_datetime(data['time'], format='%Y-%m-%d %H:%M:%S')
    data['weekofday'] = (data['datetime'].dt.dayofweek+1)/10
    data = data.drop(['datetime'],axis=1)
    return data

def c_n_degree(data,n):
    """
    角度对应{(最近close-前n close)/n}
    tan(角度) 范围太大不合适
    sin(角度) 更合理
    """
    data['ratio'+str(n)] = (data['close']-data['close'].shift(n))/n
    data['c_tan'+str(n)] = data['ratio'+str(n)].apply(lambda x:math.tan(x))
    data['c_sin'+str(n)] = data['c_tan'+str(n)].apply(lambda x:math.sin(math.atan(x)))
    data = data.drop(['ratio'+str(n),'c_tan'+str(n)],axis=1)
    return data

if __name__ == '__main__':
    pass